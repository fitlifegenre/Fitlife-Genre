// Menampilkan pesan sambutan ketika tombol "Join Us Today!" ditekan

document.addEventListener("DOMContentLoaded", function () {

    const joinButton = document.querySelector("#joinButton");

    if (joinButton) {

        joinButton.addEventListener("click", function () {

            alert("Selamat datang di FitLife! Terima kasih telah bergabung!");

        });

    }

});